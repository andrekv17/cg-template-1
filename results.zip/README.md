# cg-template
Template project for computer graphics exercises


Don't forget 
```sh
git submodule update --init --recursive
```