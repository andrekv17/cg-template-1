# Models for educational purposes

- [CornelBox](https://casual-effects.com/g3d/data10/index.html#mesh5) License: CC BY 3.0 © 2009 Morgan McGuire
- [Cube](https://casual-effects.com/g3d/data10/index.html#mesh9) License: CC0 © 2005 Morgan McGuire
- [Female](http://www.sweethome3d.com/freeModels.jsp?applicationId=SweetHome3D%23MacAppStore) License: Creative Commons Attribution 3.0 United States license © 2011 Reallusion
